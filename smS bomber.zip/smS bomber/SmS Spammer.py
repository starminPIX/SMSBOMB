
import smtplib
import time as t

def INFO(MESSAGE, CARRIER_MESSAGE, NUMBER,email_login,email_password):
    to_number = NUMBER+CARRIER_MESSAGE
    server = smtplib.SMTP( "smtp.gmail.com", 587 )
    server.starttls()           
    server.login(email_login, email_password)
    print '==================================\n'
    send(server, email_login,to_number,MESSAGE)

def send(server, email_login,to_number,MESSAGE):
    while True:
        try:
            server.sendmail(email_login, to_number, MESSAGE)
            print ('Message has been sent')
        except KeyboardInterrupt:
            print '\n=================================='
            print ('Exiting')
            exit()

def main():
    try:

        t.sleep(1)
        email_login = raw_input(' Enter your email address: ')
        t.sleep(.5)
        email_password = raw_input(' Enter your email password: ')
        t.sleep(.5)
        NUMBER = raw_input(' Enter a number to spam: ')
        t.sleep(.5)
        print ('\nCarriers: {0}att{4}, {1}tmobile{4}, {2}verizon {4}and {3}sprint' )
        CARRIER = raw_input(' Enter a carrier: ')
        t.sleep(.5)
        MESSAGE = raw_input(' Enter a message to spam: ')
        if CARRIER == 'att':
            CARRIER_MESSAGE = '@mms.att.net'
        if CARRIER == 'tmobile':
            CARRIER_MESSAGE = '@tmomail.net'
        if CARRIER == 'verizon':
            CARRIER_MESSAGE = '@vtext.com'
        if CARRIER == 'sprint':
            CARRIER_MESSAGE = '@messaging.sprintpcs.com'
        INFO(MESSAGE,CARRIER_MESSAGE,NUMBER,email_login,email_password)
    except smtplib.SMTPAuthenticationError:
        print ('Incorrect email information')
    except KeyboardInterrupt:
        print '\n'
        exit()

main()